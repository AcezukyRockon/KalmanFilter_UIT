#ifndef _MATRIX_UNITTESTS_H_
#define _MATRIX_UNITTESTS_H_

/*!
* \brief Unit tests for matrix operations
*/
void matrix_unittests();

#endif